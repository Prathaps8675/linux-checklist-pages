"""
Cryptographically Signed License Verification Engine & Persistent Host Registry.
Supports Multi-Project scoping & Master Hardware Binding.
Author: Prathap S (prathaps8675@gmail.com)
"""

import os
import json
import hmac
import hashlib
import logging
import socket
from datetime import datetime

logger = logging.getLogger(__name__)

# Master Author Info
AUTHOR_NAME = "Enterprise Licensing & Support Team"
AUTHOR_EMAIL = "prathaps8675@gmail.com"

# Master Secret Key (Can be overridden via env variable LIC_MASTER_SECRET or secret file)
SECRET_FILE = "/etc/health-dashboard.secret"
DEFAULT_LICENSE_FILE = "/opt/health-reports/license.key"
LICENSE_BACKUP_FILE = "/etc/health-dashboard.license.backup"
REGISTERED_HOSTS_FILE = "/opt/health-reports/registered_hosts.json"
DEFAULT_CLIENT_NAME = "Enterprise Community Edition"
DEFAULT_FREE_LIMIT = 10


def get_master_secret():
    """Dynamically get the current Master Secret Key from env or secret file."""
    secret = os.environ.get("LIC_MASTER_SECRET", "")
    if not secret and os.path.exists(SECRET_FILE):
        try:
            with open(SECRET_FILE, "r", encoding="utf-8") as sf:
                secret = sf.read().strip()
        except Exception:
            pass
    if not secret:
        secret = "Prathap_Linux_Health_Dashboard_Master_Secret_Key_2026"
    return secret


def get_system_machine_id():
    """Get unique machine identifier or primary MAC for hardware binding."""
    try:
        if os.path.exists("/etc/machine-id"):
            with open("/etc/machine-id", "r") as f:
                return f.read().strip()
        elif os.path.exists("/var/lib/dbus/machine-id"):
            with open("/var/lib/dbus/machine-id", "r") as f:
                return f.read().strip()
    except Exception:
        pass
    return socket.gethostname()


def compute_signature(client_name, project_name, max_servers, issue_date, expiry_date="UNLIMITED", master_id=""):
    """Compute HMAC-SHA256 signature for a license payload including expiry_date."""
    secret = get_master_secret()
    payload = f"{client_name}:{project_name}:{max_servers}:{issue_date}:{expiry_date}:{master_id}".encode("utf-8")
    return hmac.new(secret.encode("utf-8"), payload, hashlib.sha256).hexdigest()


def generate_license_data(client_name=DEFAULT_CLIENT_NAME, project_name="All Projects", max_servers=DEFAULT_FREE_LIMIT, issue_date="2026-08-06", expiry_date="UNLIMITED", master_id=""):
    """Generate a signed license dictionary with expiry duration."""
    sig = compute_signature(client_name, project_name, max_servers, issue_date, expiry_date, master_id)
    return {
        "client_name": client_name,
        "project_name": project_name,
        "max_servers": int(max_servers),
        "issue_date": issue_date,
        "expiry_date": expiry_date,
        "master_id": master_id,
        "signature": sig,
        "author": AUTHOR_NAME,
        "contact_email": AUTHOR_EMAIL,
    }


def check_anti_clock_tampering(issue_date_str):
    """
    Detect intentional clock tampering while ignoring temporary server reboot RTC clock skew.
    Only triggers if system clock is shifted backward by more than 7 days relative to registry mtime
    or prior to the license issue date.
    """
    try:
        current_dt = datetime.now()
        current_ts = current_dt.timestamp()

        # Check if clock is earlier than license issue date
        if issue_date_str and issue_date_str != "2026-08-06":
            try:
                iss_dt = datetime.strptime(issue_date_str, "%Y-%m-%d")
                if current_dt < (iss_dt - timedelta(days=1)):
                    return True
            except Exception:
                pass

        # Check against registered hosts mtime (7-day threshold to avoid false positives on reboot)
        if os.path.exists(REGISTERED_HOSTS_FILE):
            reg_mtime = os.path.getmtime(REGISTERED_HOSTS_FILE)
            if current_ts < (reg_mtime - (7 * 86400)):  # Shifted > 7 days into past
                return True
    except Exception:
        pass
    return False


def verify_license_file(license_path=DEFAULT_LICENSE_FILE):
    """
    Verify cryptographic signature, offline expiration, 14-day grace period, and hardware binding.
    Returns tuple: (is_valid: bool, max_servers: int, client_name: str, status_msg: str, project_name: str)
    """
    if not os.path.exists(license_path):
        if os.path.exists(LICENSE_BACKUP_FILE):
            try:
                import shutil
                shutil.copy2(LICENSE_BACKUP_FILE, license_path)
                logger.info("Auto-restored missing license.key from /etc backup at %s", LICENSE_BACKUP_FILE)
            except Exception as err:
                logger.warning("Failed to auto-restore license backup from /etc: %s", err)

        if not os.path.exists(license_path):
            return True, DEFAULT_FREE_LIMIT, DEFAULT_CLIENT_NAME, f"Community Edition ({DEFAULT_FREE_LIMIT} Max Servers) - Contact {AUTHOR_NAME} ({AUTHOR_EMAIL}) to Upgrade", "Default Project"

    try:
        with open(license_path, "r", encoding="utf-8") as f:
            data = json.load(f)

        client_name = data.get("client_name", "").strip()
        if not client_name or client_name == "Unknown":
            client_name = DEFAULT_CLIENT_NAME
        project_name = data.get("project_name", "All Projects")
        max_servers = int(data.get("max_servers", DEFAULT_FREE_LIMIT))
        issue_date = data.get("issue_date", "2026-08-06")
        expiry_date = data.get("expiry_date", "UNLIMITED")
        master_id = data.get("master_id", "")
        provided_sig = data.get("signature", "")

        # Signature verification
        expected_sig_new = compute_signature(client_name, project_name, max_servers, issue_date, expiry_date, master_id)
        expected_sig_old = compute_signature(client_name, project_name, max_servers, issue_date, "", master_id) if ":" not in provided_sig else ""

        if not (hmac.compare_digest(provided_sig, expected_sig_new) or (expected_sig_old and hmac.compare_digest(provided_sig, expected_sig_old))):
            logger.error("LICENSE TAMPERING DETECTED in %s! Signature mismatch.", license_path)
            return False, DEFAULT_FREE_LIMIT, client_name, f"INVALID / TAMPERED LICENSE KEY (Locked at {DEFAULT_FREE_LIMIT} Free Max) - Contact {AUTHOR_NAME} ({AUTHOR_EMAIL})", project_name

        # Anti-Clock Tamper Verification (reboot-safe)
        if check_anti_clock_tampering(issue_date):
            logger.error("CLOCK TAMPERING DETECTED! System time set backward > 7 days.")
            return False, DEFAULT_FREE_LIMIT, client_name, f"CLOCK TAMPERING DETECTED (System clock set backward) - Contact {AUTHOR_NAME} ({AUTHOR_EMAIL})", project_name

        # Offline Expiration Validation & 14-Day Renewal Grace Period
        if expiry_date and expiry_date != "UNLIMITED":
            try:
                exp_dt = datetime.strptime(expiry_date, "%Y-%m-%d")
                today = datetime.now()
                days_left = (exp_dt - today).days

                if days_left < -14:  # Beyond 14-day grace period
                    logger.error("LICENSE EXPIRED on %s for %s (Grace Period Ended)", expiry_date, client_name)
                    return False, DEFAULT_FREE_LIMIT, client_name, f"EXPIRED LICENSE KEY (Expired on {expiry_date}) - Contact {AUTHOR_NAME} ({AUTHOR_EMAIL}) to Renew", project_name
                elif days_left < 0:  # Within 14-day grace period
                    grace_remaining = 14 + days_left
                    logger.warning("LICENSE EXPIRED on %s for %s. Operating under %d-day grace period.", expiry_date, client_name, grace_remaining)
                    return True, max_servers, client_name, f"⚠️ LICENSE EXPIRED: Operating under {grace_remaining}-Day Renewal Grace Period (Expired {expiry_date})", project_name
                else:
                    return True, max_servers, client_name, f"Active License ({max_servers} Max - {days_left} Days Remaining, Expires {expiry_date})", project_name
            except Exception as pe:
                logger.warning("Failed to parse license expiry_date %s: %s", expiry_date, pe)

        # Hardware ID binding check
        if master_id:
            system_mid = get_system_machine_id()
            if system_mid != master_id:
                logger.error("HARDWARE BINDING MISMATCH in %s! Expected: %s, Got: %s", license_path, master_id, system_mid)
                return False, DEFAULT_FREE_LIMIT, client_name, f"LICENSE HARDWARE BINDING MISMATCH (Locked at {DEFAULT_FREE_LIMIT} Free Max) - Contact {AUTHOR_NAME} ({AUTHOR_EMAIL})", project_name

        return True, max_servers, client_name, f"Valid License ({max_servers} Max Servers - {project_name})", project_name

        # Verify Hardware Binding if master_id is specified
        if master_id and master_id != "*" and master_id != get_system_machine_id():
            logger.error("UNAUTHORIZED LICENSE REUSE DETECTED! License master_id '%s' does not match server ID '%s'.", master_id, get_system_machine_id())
            return False, DEFAULT_FREE_LIMIT, client_name, f"UNAUTHORIZED LICENSE REUSE (Machine Mismatch) - Contact {AUTHOR_NAME} ({AUTHOR_EMAIL})", project_name

        return True, max_servers, client_name, f"Valid License ({max_servers} Max Servers)", project_name

    except Exception as e:
        logger.error("Failed to parse license file %s: %s", license_path, e)
        return False, DEFAULT_FREE_LIMIT, "Unknown", f"LICENSE FILE ERROR (Locked at {DEFAULT_FREE_LIMIT} Free Max) - Contact {AUTHOR_NAME} ({AUTHOR_EMAIL})", "Default Project"


def save_signed_license(client_name="Enterprise Infrastructure", project_name="All Projects", max_servers=50, issue_date="2026-08-06", master_id="", path=DEFAULT_LICENSE_FILE):
    """Generate and save a signed license file and auto-backup."""
    data = generate_license_data(client_name, project_name, max_servers, issue_date, master_id)
    os.makedirs(os.path.dirname(path), exist_ok=True)
    with open(path, "w", encoding="utf-8") as f:
        json.dump(data, f, indent=2)
    os.chmod(path, 0o600)

    # Save backup copy to /etc/ for system configuration backups
    try:
        os.makedirs(os.path.dirname(LICENSE_BACKUP_FILE), exist_ok=True)
        with open(LICENSE_BACKUP_FILE, "w", encoding="utf-8") as f:
            json.dump(data, f, indent=2)
        os.chmod(LICENSE_BACKUP_FILE, 0o600)
        logger.info("Saved license backup copy to %s", LICENSE_BACKUP_FILE)
    except Exception as e:
        logger.warning("Failed to create license backup copy at %s: %s", LICENSE_BACKUP_FILE, e)

    return data


# =============================================================================
# PERSISTENT CUMULATIVE HOST REGISTRATION REGISTRY
# Prevents cheating by deleting host report directories from disk
# =============================================================================
def load_registered_hosts(registry_path=REGISTERED_HOSTS_FILE):
    """Load persistent dictionary of all registered hostnames."""
    if os.path.exists(registry_path):
        try:
            with open(registry_path, "r", encoding="utf-8") as f:
                return json.load(f)
        except Exception as e:
            logger.error("Failed to load registered_hosts.json: %s", e)
    return {}


def save_registered_hosts(hosts_dict, registry_path=REGISTERED_HOSTS_FILE):
    """Save persistent dictionary of registered hostnames."""
    os.makedirs(os.path.dirname(registry_path), exist_ok=True)
    with open(registry_path, "w", encoding="utf-8") as f:
        json.dump(hosts_dict, f, indent=2)
    os.chmod(registry_path, 0o600)


def check_and_register_host(hostname, max_servers=10):
    """
    Check if a host can register or upload.
    Persistent registry records every hostname ever seen.
    Deleting folders from disk DOES NOT free up license slots!
    
    Returns: (allowed: bool, current_count: int, max_limit: int, message: str)
    """
    if not hostname:
        return False, 0, max_servers, "Invalid hostname"

    hosts = load_registered_hosts()
    clean_host = hostname.strip().lower()

    # Existing Host check
    if clean_host in hosts:
        # Check registration rank/index of existing host
        host_keys = list(hosts.keys())
        host_rank = host_keys.index(clean_host) + 1  # 1-indexed rank

        if max_servers > 0 and host_rank > max_servers:
            logger.warning(
                "Upload REJECTED for host '%s': Rank (%d) exceeds max server limit (%d)",
                clean_host, host_rank, max_servers
            )
            return (
                False,
                len(hosts),
                max_servers,
                f"License Server Limit Exceeded (Server Rank #{host_rank} > Max {max_servers} Allowed). Contact {AUTHOR_NAME} ({AUTHOR_EMAIL}) to renew."
            )
        return True, len(hosts), max_servers, "Existing host upload allowed"

    # New Host Registration Check
    if max_servers > 0 and len(hosts) >= max_servers:
        logger.warning(
            "License limit REJECTED new host '%s': Registered count (%d) >= Max limit (%d)",
            clean_host, len(hosts), max_servers
        )
        return (
            False,
            len(hosts),
            max_servers,
            f"License Server Limit Reached ({len(hosts)}/{max_servers} Registered Servers Max). To upgrade license capacity, please contact {AUTHOR_NAME} ({AUTHOR_EMAIL})."
        )

    # Register new host in persistent registry
    hosts[clean_host] = {
        "first_seen": datetime.utcnow().strftime("%Y-%m-%d %H:%M:%S UTC"),
        "hostname": hostname,
    }
    save_registered_hosts(hosts)
    logger.info("New host '%s' registered in Persistent License Registry. Total registered: %d/%d", clean_host, len(hosts), max_servers)

    return True, len(hosts), max_servers, "New host registered successfully"


def get_registered_hosts(registry_path=REGISTERED_HOSTS_FILE):
    """Alias/getter for persistent registered host dictionary."""
    return load_registered_hosts(registry_path)


def read_license_key(license_path=DEFAULT_LICENSE_FILE):
    """
    Read and verify license file, returning (lic_data_dict, is_valid_bool, status_msg_str).
    Used by settings page and UI components.
    """
    lic_data = {
        "client_name": DEFAULT_CLIENT_NAME,
        "project_name": "All Projects",
        "max_servers": DEFAULT_FREE_LIMIT,
        "issue_date": "2026-08-06",
        "expiry_date": "UNLIMITED",
    }

    if os.path.exists(license_path):
        try:
            with open(license_path, "r", encoding="utf-8") as f:
                file_data = json.load(f)
                if isinstance(file_data, dict):
                    lic_data.update(file_data)
        except Exception as e:
            logger.warning("Failed to parse license JSON at %s: %s", license_path, e)
    elif os.path.exists(LICENSE_BACKUP_FILE):
        try:
            with open(LICENSE_BACKUP_FILE, "r", encoding="utf-8") as f:
                file_data = json.load(f)
                if isinstance(file_data, dict):
                    lic_data.update(file_data)
        except Exception as e:
            logger.warning("Failed to parse license backup JSON at %s: %s", LICENSE_BACKUP_FILE, e)

    lic_valid, max_servers, client_name, status_msg, project_name = verify_license_file(license_path)
    lic_data["max_servers"] = max_servers
    if client_name and client_name != "Unknown":
        lic_data["client_name"] = client_name
    elif not lic_data.get("client_name") or lic_data.get("client_name") == "Unknown":
        lic_data["client_name"] = DEFAULT_CLIENT_NAME

    if project_name:
        lic_data["project_name"] = project_name

    return lic_data, lic_valid, status_msg

