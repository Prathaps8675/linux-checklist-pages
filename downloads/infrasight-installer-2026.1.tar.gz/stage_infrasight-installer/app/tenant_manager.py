"""
Multi-Tenant & MSP White-Label Engine for Enterprise Linux Health Dashboard.
Supports:
- Multi-Tenant Scoping (Multiple clients on a single Master Server)
- Separate Dashboard, Users, Branding, Reports, Themes, Custom Domains
- Tenant Switcher UI for MSP Admins
- Strict Cross-Tenant Drift Comparison Isolation Rules
"""

import os
import json
import logging

logger = logging.getLogger(__name__)

TENANTS_FILE = "/opt/health-dashboard/tenants.json"

DEFAULT_TENANT_CONFIG = {
    "default": {
        "tenant_id": "default",
        "name": "Enterprise Community Edition",
        "logo_url": "/client-logo.png",
        "theme_color": "#C61D24",  # Red
        "primary_color": "#C61D24",
        "custom_domain": "",
        "created_at": "2026-08-06 00:00:00"
    }
}


def load_tenants():
    """Load tenant registry from tenants.json."""
    if not os.path.exists(TENANTS_FILE):
        save_tenants(DEFAULT_TENANT_CONFIG)
        return DEFAULT_TENANT_CONFIG
    try:
        with open(TENANTS_FILE, "r", encoding="utf-8") as f:
            data = json.load(f)
            if "default" not in data:
                data["default"] = DEFAULT_TENANT_CONFIG["default"]
            return data
    except Exception as e:
        logger.error("Failed to load tenants file %s: %s", TENANTS_FILE, e)
        return DEFAULT_TENANT_CONFIG


def save_tenants(tenants_data):
    """Persist tenant registry to tenants.json."""
    try:
        os.makedirs(os.path.dirname(TENANTS_FILE), exist_ok=True)
        with open(TENANTS_FILE, "w", encoding="utf-8") as f:
            json.dump(tenants_data, f, indent=2)
    except Exception as e:
        logger.error("Failed to save tenants file %s: %s", TENANTS_FILE, e)


def get_tenant(tenant_id):
    """Retrieve tenant metadata by tenant_id."""
    tenants = load_tenants()
    return tenants.get(tenant_id, tenants.get("default"))


def get_tenant_by_domain(domain):
    """Find tenant associated with custom domain (e.g. acme.health-dashboard.com)."""
    if not domain:
        return None
    domain_clean = domain.split(":")[0].lower()
    tenants = load_tenants()
    for tid, tmeta in tenants.items():
        cdomain = str(tmeta.get("custom_domain", "")).strip().lower()
        if cdomain and cdomain == domain_clean:
            return tmeta
    return None


def add_or_update_tenant(tenant_id, name, logo_url="/client-logo.png", theme_color="#C61D24", custom_domain=""):
    """Add or update a tenant entry."""
    tenants = load_tenants()
    tenants[tenant_id] = {
        "tenant_id": tenant_id,
        "name": name,
        "logo_url": logo_url or "/client-logo.png",
        "theme_color": theme_color or "#C61D24",
        "primary_color": theme_color or "#C61D24",
        "custom_domain": custom_domain or "",
        "updated_at": "2026-08-06 00:00:00"
    }
    save_tenants(tenants)
    return tenants[tenant_id]
