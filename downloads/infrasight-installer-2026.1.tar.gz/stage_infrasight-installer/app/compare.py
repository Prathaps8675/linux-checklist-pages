"""
Compare blueprint — Infrastructure Configuration Drift Engine.
Focuses on meaningful configuration drift (kernel, OS, mounts, services, IPs, security).
Ignores normal runtime fluctuations (uptime, memory %, swap %, CPU load, timestamps).
"""

import os
import json
import logging
from datetime import datetime

from flask import Blueprint, render_template, request, abort, session

from app.config import Config
from app.dashboard import get_hosts

compare_bp = Blueprint("compare", __name__)
logger = logging.getLogger(__name__)


# =============================================================================
# JSON LOADING & REPORT DISCOVERY
# =============================================================================

def resolve_json_filename(filename):
    """Normalize input filename (.html, .txt, or .json) to .json."""
    if not filename:
        return ""
    base = os.path.splitext(filename)[0]
    return base + ".json"


def load_json(filepath):
    """
    Load and return a JSON summary file.
    Includes auto-repair for unquoted text/comments in JSON integer fields to guarantee report comparison works.
    Returns (data, error_message).
    """
    import re

    if not os.path.isfile(filepath):
        return None, f"File not found: {filepath}"

    file_size = os.path.getsize(filepath)
    if file_size == 0:
        return None, f"File is empty (0 bytes): {filepath}"

    try:
        with open(filepath, "r", encoding="utf-8") as f:
            content = f.read()

        try:
            data = json.loads(content)
            if isinstance(data, dict):
                return data, None
        except json.JSONDecodeError:
            # Auto-repair unquoted text in integer fields (e.g. 0 (Offline...), or trailing comments)
            repaired = re.sub(r':\s*(\d+)\s*\([^)]*\)\s*([,}])', r': \1\2', content)
            repaired = re.sub(r':\s*(\d+)\s+([a-zA-Z0-9_\-/\s]+)([,}])', r': "\1 \2"\3', repaired)
            data = json.loads(repaired)
            if isinstance(data, dict):
                return data, None

        return None, f"Invalid JSON structure (expected root dictionary): {filepath}"
    except json.JSONDecodeError as e:
        logger.error("JSON decode error in %s: %s", filepath, e)
        return None, f"Invalid JSON syntax at line {e.lineno}, column {e.colno}: {e.msg}"
    except Exception as e:
        logger.error("Failed to load JSON %s: %s", filepath, e)
        return None, f"Unexpected error reading file: {str(e)}"


def get_json_reports(hostname):
    """Get all JSON reports for a hostname sorted newest-first."""
    host_dir = os.path.join(Config.WEB_ROOT, hostname)
    if not os.path.isdir(host_dir):
        return []

    reports = []
    seen = set()
    for f in sorted(os.listdir(host_dir), reverse=True):
        if f.startswith("HealthCheck_") and f != "latest.html":
            json_file = resolve_json_filename(f)
            if json_file in seen:
                continue

            json_path = os.path.join(host_dir, json_file)
            if os.path.isfile(json_path):
                seen.add(json_file)
                mtime = os.path.getmtime(json_path)
                reports.append({
                    "hostname": hostname,
                    "filename": json_file,
                    "path": json_path,
                    "mtime": mtime,
                    "mtime_str": datetime.fromtimestamp(mtime).strftime("%Y-%m-%d %H:%M:%S"),
                    "size_kb": round(os.path.getsize(json_path) / 1024, 1),
                })

    return reports


# =============================================================================
# CONFIGURATION DRIFT COMPARISON ENGINE
# =============================================================================

def compare_system(old, new):
    """Compare System specs (Hostname, OS, Kernel, Cores). Uptime is Info-only."""
    results = []
    sys_old = old.get("system", {})
    sys_new = new.get("system", {})

    drift_fields = [
        ("Hostname", "hostname"),
        ("FQDN", "fqdn"),
        ("Operating System", "os"),
        ("Kernel Version", "kernel"),
        ("CPU Cores", "cpu_cores"),
        ("Total RAM", "ram_total"),
    ]

    for label, key in drift_fields:
        old_val = str(sys_old.get(key, "N/A")).strip()
        new_val = str(sys_new.get(key, "N/A")).strip()
        changed = old_val != new_val
        results.append({
            "item": label,
            "previous": old_val,
            "current": new_val,
            "status": "CHANGED" if changed else "NO_CHANGE",
            "is_drift": changed,
            "type": "text",
        })

    # Uptime is informational only (never marked as drift)
    def _parse_uptime(d):
        u = d.get("uptime")
        if u and str(u).strip() not in ("N/A", ""):
            return str(u).strip()
        secs = d.get("uptime_seconds")
        if secs is not None and str(secs).strip().isdigit():
            s = int(secs)
            days = s // 86400
            hours = (s % 86400) // 3600
            mins = (s % 3600) // 60
            parts = []
            if days > 0:
                parts.append(f"{days}d")
            if hours > 0:
                parts.append(f"{hours}h")
            parts.append(f"{mins}m")
            return " ".join(parts) or "0m"
        return "N/A"

    old_upt = _parse_uptime(sys_old)
    new_upt = _parse_uptime(sys_new)
    results.append({
        "item": "System Uptime",
        "previous": old_upt,
        "current": new_upt,
        "status": "INFO",
        "is_drift": False,
        "type": "text",
    })

    return results


def compare_storage(old, new):
    """Compare Mount Point structure and usage. Support all physical, virtual, Docker, K8s, LVM, NFS, CIFS mounts."""
    results = []

    def get_fs(data):
        st = data.get("storage", [])
        if isinstance(st, dict):
            items = st.get("filesystems", [])
        elif isinstance(st, list):
            items = st
        else:
            items = []
        return {item["mount"]: item for item in items if isinstance(item, dict) and "mount" in item}

    fs_old = get_fs(old)
    fs_new = get_fs(new)

    # Sort all mount points alphabetically
    all_mounts = sorted(set(list(fs_old.keys()) + list(fs_new.keys())))

    critical_mount_prefixes = (
        "/", "/boot", "/boot/efi", "/var", "/home", "/opt", "/tmp", "/usr", "/data", "/backup", "/srv"
    )

    for mount in all_mounts:
        old_entry = fs_old.get(mount)
        new_entry = fs_new.get(mount)

        if old_entry and not new_entry:
            old_fs = old_entry.get("filesystem", "Present")
            old_fstype = old_entry.get("fstype", "")
            is_nfs_cifs = old_fstype.lower() in ("nfs", "nfs4", "cifs", "smbfs") or old_fs.startswith("//") or ":" in old_fs
            is_critical = mount in critical_mount_prefixes or is_nfs_cifs

            status = "CRITICAL" if is_critical else "REMOVED"
            prev_desc = f"{old_fs} [{old_fstype}]" if old_fstype else old_fs

            results.append({
                "item": f"Mount {mount}",
                "previous": prev_desc,
                "current": "Missing / Unmounted",
                "status": status,
                "is_drift": True,
                "type": "text",
            })
        elif not old_entry and new_entry:
            new_fs = new_entry.get("filesystem", "Present")
            new_fstype = new_entry.get("fstype", "")
            curr_desc = f"{new_fs} [{new_fstype}]" if new_fstype else new_fs

            results.append({
                "item": f"Mount {mount}",
                "previous": "Not Present",
                "current": curr_desc,
                "status": "ADDED",
                "is_drift": True,
                "type": "text",
            })
        else:
            old_fs = old_entry.get("filesystem", "")
            new_fs = new_entry.get("filesystem", "")
            old_fstype = old_entry.get("fstype", "")
            new_fstype = new_entry.get("fstype", "")

            old_pct_raw = str(old_entry.get("used_percent") or old_entry.get("use_pct", "0")).replace("%", "")
            new_pct_raw = str(new_entry.get("used_percent") or new_entry.get("use_pct", "0")).replace("%", "")

            fs_changed = old_fs != new_fs
            type_changed = old_fstype and new_fstype and old_fstype != new_fstype

            try:
                old_p = int(old_pct_raw)
                new_p = int(new_pct_raw)
                usage_changed = abs(old_p - new_p) >= 15
            except ValueError:
                old_p, new_p = old_pct_raw, new_pct_raw
                usage_changed = old_p != new_p

            prev_str = f"{old_fs} [{old_fstype}] ({old_p}%)" if old_fstype else f"{old_fs} ({old_p}%)"
            curr_str = f"{new_fs} [{new_fstype}] ({new_p}%)" if new_fstype else f"{new_fs} ({new_p}%)"

            if fs_changed or type_changed:
                results.append({
                    "item": f"Mount {mount}",
                    "previous": prev_str,
                    "current": curr_str,
                    "status": "CHANGED",
                    "is_drift": True,
                    "type": "text",
                })
            elif usage_changed:
                results.append({
                    "item": f"Mount {mount} (Usage)",
                    "previous": f"{old_p}%",
                    "current": f"{new_p}%",
                    "status": "CHANGED",
                    "is_drift": True,
                    "type": "text",
                })
            else:
                results.append({
                    "item": f"Mount {mount}",
                    "previous": prev_str,
                    "current": curr_str,
                    "status": "NO_CHANGE",
                    "is_drift": False,
                    "type": "text",
                })

    return results


def compare_memory(old, new):
    """Memory & Swap usage fluctuate naturally. Displayed for reference only (is_drift = False)."""
    results = []
    mem_old = old.get("memory", {})
    mem_new = new.get("memory", {})

    ram_old_pct = mem_old.get("ram_used_pct", "N/A")
    ram_new_pct = mem_new.get("ram_used_pct", "N/A")
    ram_old_str = f"{mem_old.get('ram_used', 'N/A')} / {mem_old.get('ram_total', 'N/A')} ({ram_old_pct})"
    ram_new_str = f"{mem_new.get('ram_used', 'N/A')} / {mem_new.get('ram_total', 'N/A')} ({ram_new_pct})"

    results.append({
        "item": "RAM Memory Utilization",
        "previous": ram_old_str,
        "current": ram_new_str,
        "status": "INFO",
        "is_drift": False,
        "type": "text",
    })

    swap_old_pct = mem_old.get("swap_used_pct", "N/A")
    swap_new_pct = mem_new.get("swap_used_pct", "N/A")
    swap_old_str = f"{mem_old.get('swap_used', 'N/A')} / {mem_old.get('swap_total', 'N/A')} ({swap_old_pct})"
    swap_new_str = f"{mem_new.get('swap_used', 'N/A')} / {mem_new.get('swap_total', 'N/A')} ({swap_new_pct})"

    results.append({
        "item": "Swap Memory Utilization",
        "previous": swap_old_str,
        "current": swap_new_str,
        "status": "INFO",
        "is_drift": False,
        "type": "text",
    })

    return results


def normalize_service_status(st):
    """
    Extract and normalize service operational state.
    Returns: 'Running', 'Active', 'Failed', 'Inactive', or 'Not Installed'.
    """
    if not st:
        return "Not Installed"
    
    st_str = str(st).strip()
    st_upper = st_str.upper()

    # Check for Not Installed / Unit not found patterns
    if (
        "NOT INSTALLED" in st_upper or
        "NOT_INSTALLED" in st_upper or
        "UNIT COULD NOT BE FOUND" in st_upper or
        "LOADED: NOT-FOUND" in st_upper or
        "COULD NOT BE FOUND" in st_upper or
        "N/A" in st_upper or
        "UNKNOWN" in st_upper or
        "CANNOT STAT" in st_upper
    ):
        return "Not Installed"

    # Extract Active line if multiline systemctl status string is passed
    if "ACTIVE:" in st_upper:
        for line in st_str.splitlines():
            line_u = line.strip().upper()
            if line_u.startswith("ACTIVE:"):
                if "ACTIVE (RUNNING)" in line_u or "RUNNING" in line_u:
                    return "Running"
                elif "ACTIVE (EXITED)" in line_u or "ACTIVE" in line_u:
                    return "Active"
                elif "FAILED" in line_u:
                    return "Failed"
                elif "INACTIVE" in line_u or "DEAD" in line_u or "STOPPED" in line_u:
                    return "Inactive"

    if "ACTIVE (RUNNING)" in st_upper or "RUNNING" in st_upper:
        return "Running"
    elif "ACTIVE (EXITED)" in st_upper or "ACTIVE" in st_upper:
        return "Active"
    elif "FAILED" in st_upper:
        return "Failed"
    elif "INACTIVE" in st_upper or "STOPPED" in st_upper or "DEAD" in st_upper:
        return "Inactive"

    return "Not Installed"


def compare_services(old, new):
    """Compare Service State (Running, Active, Failed, Inactive, Not Installed)."""
    results = []
    svc_old = old.get("services", {})
    svc_new = new.get("services", {})

    # Support dynamic service set from both old/new keys
    all_services = sorted(set(list(svc_old.keys()) + list(svc_new.keys())))

    for svc in all_services:
        raw_old = svc_old.get(svc, "Not Installed")
        raw_new = svc_new.get(svc, "Not Installed")

        norm_old = normalize_service_status(raw_old)
        norm_new = normalize_service_status(raw_new)

        if norm_old == norm_new:
            status = "NO_CHANGE"
            is_drift = False
        elif norm_old == "Not Installed" and norm_new != "Not Installed":
            status = "ADDED"
            is_drift = True
        elif norm_old != "Not Installed" and norm_new == "Not Installed":
            status = "REMOVED"
            is_drift = True
        else:
            status = "CHANGED"
            is_drift = True

        results.append({
            "item": f"Service: {svc}",
            "previous": norm_old,
            "current": norm_new,
            "status": status,
            "is_drift": is_drift,
            "type": "text",
        })

    return results


def parse_interface_ips(net_data):
    """
    Parse network interfaces. Supports old array-of-strings or new array-of-dicts schemas.
    Ignores temporary IPv6 link-local addresses (fe80::*).
    """
    ifaces = {}
    
    # New schema
    if "interfaces" in net_data:
        for item in net_data.get("interfaces", []):
            ifaces[item.get("name", "unknown")] = item.get("ipv4", "Not Configured")
        return ifaces
        
    # Old schema
    ip_list = net_data.get("ip_addresses", [])
    if not isinstance(ip_list, list):
        return ifaces

    for entry in ip_list:
        s = str(entry).strip()
        if not s:
            continue
        parts = s.split()
        if len(parts) >= 2:
            iface, ip = parts[0], parts[1]
        else:
            continue

        if ip.startswith("fe80::"):
            continue

        if iface not in ifaces:
            ifaces[iface] = ip
        else:
            ifaces[iface] = f"{ifaces[iface]}, {ip}"

    return ifaces


def compare_network(old, new):
    """Compare Network configuration."""
    results = []
    net_old = old.get("network", {})
    net_new = new.get("network", {})

    old_ifaces = parse_interface_ips(net_old)
    new_ifaces = parse_interface_ips(net_new)

    all_ifaces = sorted(set(list(old_ifaces.keys()) + list(new_ifaces.keys())))

    for iface in all_ifaces:
        old_ip = old_ifaces.get(iface, "Not Configured")
        new_ip = new_ifaces.get(iface, "Not Configured")

        if old_ip == new_ip:
            results.append({
                "item": f"Interface: {iface}",
                "previous": old_ip,
                "current": new_ip,
                "status": "NO_CHANGE",
                "is_drift": False,
                "type": "text",
            })
        elif old_ip == "Not Configured":
            results.append({
                "item": f"Interface: {iface}",
                "previous": "Not Configured",
                "current": new_ip,
                "status": "ADDED",
                "is_drift": True,
                "type": "text",
            })
        elif new_ip == "Not Configured":
            results.append({
                "item": f"Interface: {iface}",
                "previous": old_ip,
                "current": "Not Configured",
                "status": "REMOVED",
                "is_drift": True,
                "type": "text",
            })
        else:
            results.append({
                "item": f"Interface: {iface}",
                "previous": old_ip,
                "current": new_ip,
                "status": "CHANGED",
                "is_drift": True,
                "type": "text",
            })

    # Route Table Comparison
    old_routes = net_old.get("routes", [])
    new_routes = net_new.get("routes", [])

    old_r_set = set(old_routes)
    new_r_set = set(new_routes)
    
    added_routes = new_r_set - old_r_set
    removed_routes = old_r_set - new_r_set
    unchanged_routes = old_r_set & new_r_set
    
    for r in unchanged_routes:
        results.append({
            "item": "Network Route",
            "previous": r,
            "current": r,
            "status": "NO_CHANGE",
            "is_drift": False,
            "type": "text",
        })
    for r in added_routes:
        results.append({
            "item": "Network Route",
            "previous": "Not Configured",
            "current": r,
            "status": "ADDED",
            "is_drift": True,
            "type": "text",
        })
    for r in removed_routes:
        results.append({
            "item": "Network Route",
            "previous": r,
            "current": "Not Configured",
            "status": "REMOVED",
            "is_drift": True,
            "type": "text",
        })

    # DNS Comparison
    old_dns = net_old.get("dns", [])
    new_dns = net_new.get("dns", [])

    old_d_set = set(old_dns)
    new_d_set = set(new_dns)
    
    added_dns = new_d_set - old_d_set
    removed_dns = old_d_set - new_d_set
    unchanged_dns = old_d_set & new_d_set
    
    for d in unchanged_dns:
        results.append({
            "item": "DNS Server/Search",
            "previous": d,
            "current": d,
            "status": "NO_CHANGE",
            "is_drift": False,
            "type": "text",
        })
    for d in added_dns:
        results.append({
            "item": "DNS Server/Search",
            "previous": "Not Configured",
            "current": d,
            "status": "ADDED",
            "is_drift": True,
            "type": "text",
        })
    for d in removed_dns:
        results.append({
            "item": "DNS Server/Search",
            "previous": d,
            "current": "Not Configured",
            "status": "REMOVED",
            "is_drift": True,
            "type": "text",
        })

    return results


def compare_security(old, new):
    """Compare Security Settings (SELinux, NTP Sync)."""
    results = []
    sec_old = old.get("security", {})
    sec_new = new.get("security", {})

    old_sel = str(sec_old.get("selinux", "Disabled")).strip()
    new_sel = str(sec_new.get("selinux", "Disabled")).strip()
    sel_changed = old_sel != new_sel

    results.append({
        "item": "SELinux Mode",
        "previous": old_sel,
        "current": new_sel,
        "status": "CHANGED" if sel_changed else "NO_CHANGE",
        "is_drift": sel_changed,
        "type": "text",
    })

    old_ntp = str(sec_old.get("ntp", "Not Synchronized")).strip()
    new_ntp = str(sec_new.get("ntp", "Not Synchronized")).strip()
    ntp_changed = old_ntp != new_ntp

    results.append({
        "item": "NTP Time Synchronization",
        "previous": old_ntp,
        "current": new_ntp,
        "status": "CHANGED" if ntp_changed else "NO_CHANGE",
        "is_drift": ntp_changed,
        "type": "text",
    })

    fw_old = sec_old.get("firewall", {})
    fw_new = sec_new.get("firewall", {})

    old_fw_type = str(fw_old.get("type", "Unknown")).strip()
    new_fw_type = str(fw_new.get("type", "Unknown")).strip()
    fw_type_changed = old_fw_type != new_fw_type

    results.append({
        "item": "Firewall Type",
        "previous": old_fw_type,
        "current": new_fw_type,
        "status": "CHANGED" if fw_type_changed else "NO_CHANGE",
        "is_drift": fw_type_changed,
        "type": "text",
    })

    old_fw_status = str(fw_old.get("status", "Unknown")).strip()
    new_fw_status = str(fw_new.get("status", "Unknown")).strip()
    fw_status_changed = old_fw_status != new_fw_status

    results.append({
        "item": "Firewall Status",
        "previous": old_fw_status,
        "current": new_fw_status,
        "status": "CHANGED" if fw_status_changed else "NO_CHANGE",
        "is_drift": fw_status_changed,
        "type": "text",
    })

    return results


def compare_patch_management(old, new):
    """Compare Patch Management & RHEL Kernel Recommendation engine outputs."""
    results = []
    pm_old = old.get("patch_management", {})
    pm_new = new.get("patch_management", {})

    fields = [
        ("Available Package Updates", "available_updates"),
        ("Security Updates Pending", "security_updates"),
        ("Critical Security Updates", "critical_updates"),
        ("Kernel Package Update Ready", "kernel_update_available"),
        ("System Reboot Required", "reboot_required"),
        ("Last Patch Date", "last_patch_date"),
        ("Patch Compliance Score", "patch_compliance_percent"),
        ("Running Kernel Version", "running_kernel"),
        ("Recommended Target Vendor Kernel", "recommended_kernel"),
        ("CVE Security Errata & Advisory", "cve_advisory"),
    ]

    for label, key in fields:
        old_val = str(pm_old.get(key, "N/A")).strip()
        new_val = str(pm_new.get(key, "N/A")).strip()

        if key == "patch_compliance_percent" and old_val not in ("N/A", "") and not old_val.endswith("%"):
            old_val = f"{old_val}%"
        if key == "patch_compliance_percent" and new_val not in ("N/A", "") and not new_val.endswith("%"):
            new_val = f"{new_val}%"

        changed = old_val != new_val
        status = "CHANGED" if changed else "NO_CHANGE"

        if key in ("security_updates", "critical_updates") and new_val not in ("0", "0%", "N/A"):
            status = "WARNING"
        if key == "reboot_required" and "Yes" in new_val:
            status = "WARNING"

        results.append({
            "item": label,
            "previous": old_val,
            "current": new_val,
            "status": status,
            "is_drift": changed,
            "type": "text",
        })

    return results


def generate_summary(categories, report_old_time, report_new_time):
    """Calculate meaningful configuration drift summary statistics."""
    drift_count = 0
    changes_count = 0
    added_count = 0
    removed_count = 0
    critical_count = 0
    no_change_count = 0
    total_evaluated = 0

    for cat_results in categories.values():
        for item in cat_results:
            total_evaluated += 1
            if item["status"] == "NO_CHANGE":
                no_change_count += 1
            elif item["status"] == "ADDED":
                added_count += 1
                drift_count += 1
            elif item["status"] == "REMOVED":
                removed_count += 1
                drift_count += 1
            elif item["status"] == "CHANGED":
                changes_count += 1
                drift_count += 1
                
            if item["status"] not in ("NO_CHANGE", "INFO"):
                if item["status"] == "CRITICAL" or item["item"] in ("Operating System", "Kernel Version", "Total RAM", "CPU Cores", "SELinux Mode", "Firewall Status"):
                    critical_count += 1

    overall = "HEALTHY" if drift_count == 0 else "DRIFT_DETECTED"

    storage_items = categories.get("Storage & Mount Structure", [])
    storage_summary = {
        "total_mounts": len(storage_items),
        "no_change_count": sum(1 for i in storage_items if i["status"] == "NO_CHANGE"),
        "changed_count": sum(1 for i in storage_items if i["status"] == "CHANGED"),
        "added_count": sum(1 for i in storage_items if i["status"] == "ADDED"),
        "removed_count": sum(1 for i in storage_items if i["status"] == "REMOVED"),
        "critical_count": sum(1 for i in storage_items if i["status"] == "CRITICAL"),
    }

    return {
        "report_old_time": report_old_time,
        "report_new_time": report_new_time,
        "drift_count": drift_count,
        "changes_count": changes_count,
        "added_count": added_count,
        "removed_count": removed_count,
        "critical_count": critical_count,
        "no_change_count": no_change_count,
        "total_evaluated": total_evaluated,
        "overall": overall,
        "storage_summary": storage_summary,
    }


# =============================================================================
# ROUTES
# =============================================================================

@compare_bp.route("/compare/<hostname>", methods=["GET", "POST"])
@compare_bp.route("/compare/<hostname>/run", methods=["GET", "POST"])
def compare_page(hostname):
    """Unified route handling comparison GET and POST. Never returns blank page."""
    host_dir = os.path.join(Config.WEB_ROOT, hostname)
    if not os.path.isdir(host_dir):
        logger.warning("Compare requested for non-existent host directory: %s", hostname)
        abort(404)

    all_hosts = get_hosts()
    reports = get_json_reports(hostname)

    compare_type = request.form.get("compare_type") or request.args.get("compare_type", "same_server")
    target_host = request.form.get("target_host") or request.args.get("target_host")

    raw_old = request.form.get("report_old") or request.args.get("report_old")
    raw_new = request.form.get("report_new") or request.args.get("report_new")
    raw_target = request.form.get("target_report") or request.args.get("target_report")

    def parse_meta(raw_val):
        if not raw_val:
            return None
        try:
            return json.loads(raw_val)
        except json.JSONDecodeError:
            return {"filename": raw_val}

    meta_new = parse_meta(raw_new)
    
    if compare_type == "another_server":
        meta_old = parse_meta(raw_target)
    else:
        meta_old = parse_meta(raw_old)

    report_old = meta_old.get("filename") if meta_old else None
    report_new = meta_new.get("filename") if meta_new else None

    # Handle defaults for initial page load
    if compare_type == "another_server":
        if not report_new and len(reports) > 0:
            report_new = reports[0]["filename"]
            meta_new = reports[0]
            
        if target_host and not report_old:
            target_reports = get_json_reports(target_host)
            if target_reports:
                report_old = target_reports[0]["filename"]
                meta_old = target_reports[0]
    else:
        if len(reports) >= 2:
            if not report_new:
                report_new = reports[0]["filename"]
                meta_new = reports[0]
            if not report_old:
                report_old = reports[1]["filename"]
                meta_old = reports[1]

    target_reports = get_json_reports(target_host) if target_host else []

    categories = None
    summary = None
    error_msg = None

    old_time_str = "N/A"
    new_time_str = "N/A"
    
    old_host_display = hostname
    new_host_display = hostname

    if compare_type == "another_server" and target_host and report_old:
        old_host_display = target_host
        for r in target_reports:
            if r["filename"] == report_old:
                old_time_str = r["mtime_str"]
    else:
        for r in reports:
            if r["filename"] == report_old:
                old_time_str = r["mtime_str"]
                
    for r in reports:
        if r["filename"] == report_new:
            new_time_str = r["mtime_str"]

    if compare_type == "same_server" and len(reports) < 2:
        error_msg = "At least two JSON health reports are required to perform a Before vs After activity comparison."
    elif compare_type == "another_server" and (not target_host or not report_old):
        error_msg = "Please select a target server and report to compare against."
    elif report_old and report_new:
        # Secure Path resolution and Validation
        old_dir = os.path.join(Config.WEB_ROOT, target_host) if compare_type == "another_server" and target_host else host_dir
        
        # Use paths from metadata if available, otherwise construct
        old_path = meta_old.get("path") if meta_old and meta_old.get("path") else os.path.join(old_dir, report_old)
        new_path = meta_new.get("path") if meta_new and meta_new.get("path") else os.path.join(host_dir, report_new)
        
        # Verify ownership
        expected_old_host = target_host if compare_type == "another_server" else hostname
        if meta_old and meta_old.get("hostname") and meta_old.get("hostname") != expected_old_host:
            error_msg = f"The selected report does not belong to the selected server ({expected_old_host}). Please choose a valid report."
        elif meta_new and meta_new.get("hostname") and meta_new.get("hostname") != hostname:
            error_msg = f"The selected report does not belong to the selected server ({hostname}). Please choose a valid report."
        elif not os.path.isfile(old_path) or not os.path.isfile(new_path):
            error_msg = "Selected report no longer exists. Please refresh the report list."
        else:
            old_data, old_err = load_json(old_path)
            new_data, new_err = load_json(new_path)

            old_tenant = old_data.get("tenant_id", "default") if old_data else "default"
            new_tenant = new_data.get("tenant_id", "default") if new_data else "default"

            if old_tenant != new_tenant:
                error_msg = f"🔒 Cross-Tenant Drift Comparison Restricted: Server '{old_host_display}' (Tenant: {old_tenant}) cannot be compared with '{new_host_display}' (Tenant: {new_tenant}) to enforce tenant privacy guidelines."
            elif old_data and new_data:
                categories = {
                    "System & Operating System": compare_system(old_data, new_data),
                    "Patch Management & RHEL Kernel Advisory": compare_patch_management(old_data, new_data),
                    "Storage & Mount Structure": compare_storage(old_data, new_data),
                    "Key Infrastructure Services": compare_services(old_data, new_data),
                    "Network & Routing Rules": compare_network(old_data, new_data),
                    "Security & Time Sync": compare_security(old_data, new_data),
                    "Memory & Swap Utilization (Informational)": compare_memory(old_data, new_data),
                }
                summary = generate_summary(categories, old_time_str, new_time_str)
            else:
                err_details = []
                if old_err: err_details.append(f"Previous Report ({report_old}): {old_err}")
                if new_err: err_details.append(f"Current Report ({report_new}): {new_err}")
                error_msg = "Unable to parse report files.\n" + "\n".join(err_details)

    return render_template(
        "compare.html",
        hostname=hostname,
        json_reports=reports,
        all_hosts=all_hosts,
        compare_type=compare_type,
        target_host=target_host,
        old_host_display=old_host_display,
        new_host_display=new_host_display,
        results=categories,
        summary=summary,
        report_old=report_old,
        report_new=report_new,
        old_time_str=old_time_str,
        new_time_str=new_time_str,
        error_msg=error_msg,
        target_reports=target_reports,
        user=session.get("user"),
        auth_enabled=Config.AUTH_ENABLED,
    )


@compare_bp.route("/compare/<hostname>/import", methods=["POST"])
def import_external_report(hostname):
    """Import an external report (.json/.html) for cross-server/cross-project comparison."""
    if Config.AUTH_ENABLED and "user" not in session:
        from flask import redirect, url_for
        return redirect(url_for("auth.login"))

    from flask import flash, redirect, url_for
    import re

    if "file" not in request.files:
        flash("No report file uploaded for comparison.", "danger")
        return redirect(url_for("compare.compare_page", hostname=hostname))

    uploaded_file = request.files["file"]
    if not uploaded_file or not uploaded_file.filename:
        flash("Empty filename provided.", "danger")
        return redirect(url_for("compare.compare_page", hostname=hostname))

    filename = uploaded_file.filename
    ext = os.path.splitext(filename)[1].lower()
    if ext not in (".json", ".html", ".htm", ".txt"):
        flash(f"Unsupported file type '{ext}'. Allowed: .json, .html, .txt", "danger")
        return redirect(url_for("compare.compare_page", hostname=hostname))

    content_bytes = uploaded_file.read()
    content = content_bytes.decode("utf-8", errors="ignore")
    target_host = "external_server"

    # Extract hostname from JSON if available
    if ext == ".json":
        try:
            data = json.loads(content)
            if isinstance(data, dict):
                target_host = data.get("system", {}).get("hostname", target_host)
        except Exception:
            pass

    from app.upload_api import sanitize_hostname
    clean_target = sanitize_hostname(target_host) or "external_server"
    host_dir = os.path.join(Config.WEB_ROOT, clean_target)
    os.makedirs(host_dir, exist_ok=True)

    json_filename = resolve_json_filename(filename)
    save_path = os.path.join(host_dir, json_filename)

    with open(save_path, "wb") as f:
        f.write(content_bytes)

    flash(f"External report '{filename}' imported successfully for server '{clean_target}'.", "success")
    return redirect(url_for("compare.compare_page", hostname=hostname, compare_type="another_server", target_host=clean_target))
