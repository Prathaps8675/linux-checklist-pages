"""
Authentication blueprint — Login, Logout, Session Management.
Uses werkzeug password hashing with users.json file storage.
"""

import os
import json
import time
import logging

from flask import Blueprint, render_template, request, redirect, url_for, session, flash
from werkzeug.security import check_password_hash

from app.config import Config

auth_bp = Blueprint("auth", __name__)
logger = logging.getLogger(__name__)


def load_users():
    """Load users from the users.json file."""
    users_file = Config.USERS_FILE
    if not os.path.isfile(users_file):
        return {}
    try:
        with open(users_file, "r") as f:
            data = json.load(f)
        users = data.get("users", {})
        # Ensure default role for any account if role is not set
        for u, uinfo in users.items():
            if isinstance(uinfo, dict) and ("role" not in uinfo or not uinfo.get("role")):
                uinfo["role"] = "admin" if len(users) == 1 else uinfo.get("role", "admin")
        return users
    except Exception as e:
        logger.error("Failed to load users file %s: %s", users_file, e)
        return {}


def save_users(users_data):
    """Save users dictionary to users.json file."""
    users_file = Config.USERS_FILE
    try:
        os.makedirs(os.path.dirname(users_file), exist_ok=True)
        with open(users_file, "w", encoding="utf-8") as f:
            json.dump({"users": users_data}, f, indent=2)
        return True
    except Exception as e:
        logger.error("Failed to save users file %s: %s", users_file, e)
        return False


@auth_bp.route("/login", methods=["GET", "POST"])
def login():
    """Handle login page and authentication."""
    if not Config.AUTH_ENABLED:
        return redirect(url_for("dashboard.index"))

    if "user" in session:
        return redirect(url_for("dashboard.index"))

    error = None
    timeout = request.args.get("timeout")

    if request.method == "POST":
        username = request.form.get("username", "").strip()
        password = request.form.get("password", "")
        remember = request.form.get("remember_me") == "on"

        users = load_users()
        user_info = users.get(username, {})

        if username in users and check_password_hash(user_info.get("password", ""), password):
            session["user"] = username
            session["role"] = user_info.get("role", "admin")
            session["client_permission"] = user_info.get("client_permission", "all")
            session["login_time"] = time.time()
            session["remember_me"] = remember
            session.permanent = remember

            logger.info("User '%s' logged in (Role: %s, Permission: %s)", username, session["role"], session["client_permission"])
            return redirect(url_for("dashboard.index"))
        else:
            error = "Invalid username or password."
            logger.warning("Failed login attempt for user '%s' from %s", username, request.remote_addr)

    return render_template("login.html", error=error, timeout=timeout)


@auth_bp.route("/logout")
def logout():
    """Destroy session and redirect to login."""
    username = session.get("user", "unknown")
    session.clear()
    logger.info("User '%s' logged out.", username)
    return redirect(url_for("auth.login"))


@auth_bp.route("/settings", methods=["GET"])
def settings_page():
    """Render Web User Management & System Settings page."""
    if Config.AUTH_ENABLED and "user" not in session:
        return redirect(url_for("auth.login"))

    from app.license_manager import read_license_key, get_system_machine_id, get_registered_hosts
    from app.tenant_manager import load_tenants

    users = load_users()
    lic_data, lic_valid, lic_err = read_license_key()
    machine_id = get_system_machine_id()
    registered_hosts = get_registered_hosts()
    tenants = load_tenants()

    current_u = session.get("user", "admin")
    current_user_info = users.get(current_u, {})
    current_r = session.get("role") or current_user_info.get("role", "user")

    return render_template(
        "settings.html",
        users=users,
        lic_data=lic_data,
        lic_valid=lic_valid,
        lic_err=lic_err,
        machine_id=machine_id,
        registered_count=len(registered_hosts),
        tenants=tenants,
        user=current_u,
        current_user=current_u,
        current_role=current_r
    )


@auth_bp.route("/settings/user/add", methods=["POST"])
def user_add():
    """Add a new user with client permission scope (Admin only)."""
    if Config.AUTH_ENABLED and "user" not in session:
        return redirect(url_for("auth.login"))

    current_r = session.get("role", "user")
    if current_r != "admin":
        flash("Permission Denied: Only Administrator accounts can create new users.", "danger")
        return redirect(url_for("auth.settings_page"))

    from werkzeug.security import generate_password_hash

    username = request.form.get("username", "").strip()
    password = request.form.get("password", "")
    role = request.form.get("role", "user")
    client_permission = request.form.get("client_permission", "all")

    if not username or not password:
        flash("Username and Password are required.", "danger")
        return redirect(url_for("auth.settings_page"))

    users = load_users()
    if username in users:
        flash(f"User '{username}' already exists.", "warning")
        return redirect(url_for("auth.settings_page"))

    users[username] = {
        "password": generate_password_hash(password),
        "role": role,
        "client_permission": client_permission,
        "created_at": time.strftime("%Y-%m-%d %H:%M:%S")
    }

    save_users(users)
    flash(f"User '{username}' created successfully with permission scope: {client_permission}.", "success")
    return redirect(url_for("auth.settings_page"))


@auth_bp.route("/settings/user/password", methods=["POST"])
def user_password():
    """Change password for self, or any user if Admin."""
    if Config.AUTH_ENABLED and "user" not in session:
        return redirect(url_for("auth.login"))

    current_u = session.get("user")
    current_r = session.get("role", "user")

    username = request.form.get("username", "").strip()
    new_password = request.form.get("new_password", "")

    # Security check: Non-admins can only change their own password!
    if current_r != "admin" and username != current_u:
        flash("Permission Denied: Only Administrators can reset passwords for other users.", "danger")
        return redirect(url_for("auth.settings_page"))

    if not username or not new_password:
        flash("Username and New Password are required.", "danger")
        return redirect(url_for("auth.settings_page"))

    users = load_users()
    if username not in users:
        flash(f"User '{username}' not found.", "danger")
        return redirect(url_for("auth.settings_page"))

    users[username]["password"] = generate_password_hash(new_password)
    save_users(users)
    flash(f"Password for user '{username}' updated successfully.", "success")
    return redirect(url_for("auth.settings_page"))


@auth_bp.route("/settings/user/delete", methods=["POST"])
def user_delete():
    """Delete a user (Admin only)."""
    if Config.AUTH_ENABLED and "user" not in session:
        return redirect(url_for("auth.login"))

    current_r = session.get("role", "user")
    if current_r != "admin":
        flash("Permission Denied: Only Administrator accounts can delete users.", "danger")
        return redirect(url_for("auth.settings_page"))

    username = request.form.get("username", "").strip()
    if username == session.get("user"):
        flash("You cannot delete your own logged in account.", "danger")
        return redirect(url_for("auth.settings_page"))

    users = load_users()
    if username in users:
        del users[username]
        save_users(users)
        flash(f"User '{username}' deleted successfully.", "success")
    return redirect(url_for("auth.settings_page"))


@auth_bp.route("/settings/license/revoke", methods=["POST"])
def license_revoke():
    """Revoke/deactivate commercial license key and revert to Free Community Edition (Admin only)."""
    if Config.AUTH_ENABLED and "user" not in session:
        return redirect(url_for("auth.login"))

    current_r = session.get("role", "user")
    if current_r != "admin":
        flash("Permission Denied: Only Administrator accounts can revoke license keys.", "danger")
        return redirect(url_for("auth.settings_page"))

    import os
    from app.license_manager import DEFAULT_LICENSE_FILE, LICENSE_BACKUP_FILE

    removed = False
    for path in (DEFAULT_LICENSE_FILE, LICENSE_BACKUP_FILE):
        if os.path.exists(path):
            try:
                os.remove(path)
                removed = True
            except Exception:
                pass

    if removed:
        flash("Commercial License Key deactivated. Dashboard reverted to Free Community Edition (10 Hosts Limit).", "warning")
    else:
        flash("No active commercial license file found to remove.", "info")

    return redirect(url_for("auth.settings_page"))
