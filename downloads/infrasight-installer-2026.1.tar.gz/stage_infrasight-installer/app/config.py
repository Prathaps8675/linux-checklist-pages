"""Configuration module for the Enterprise Linux Health Dashboard."""

import os
import secrets


def _load_conf_file(path):
    d = {}
    if os.path.isfile(path):
        try:
            with open(path, "r", encoding="utf-8") as f:
                for line in f:
                    line = line.strip()
                    if line and not line.startswith("#") and "=" in line:
                        k, v = line.split("=", 1)
                        d[k.strip()] = v.strip().strip("\"'")
        except Exception:
            pass
    return d


_conf_data = _load_conf_file("/opt/infrasight/infrasight.conf")
if not _conf_data:
    _conf_data = _load_conf_file("/opt/health-reports/health-dashboard.conf")
if not _conf_data:
    _conf_data = _load_conf_file("/opt/health-dashboard/health-dashboard.conf")


class Config:
    """Application configuration loaded from environment variables with sensible defaults."""

    # Flask core (Unlimited Upload Size)
    SECRET_KEY = os.environ.get("SECRET_KEY", secrets.token_hex(32))
    MAX_CONTENT_LENGTH = None  # No upload size limit

    # Paths (InfraSight Enterprise Directory Structure)
    WEB_ROOT = os.environ.get("WEB_ROOT", "/var/www/html/infrasight/reports" if os.path.exists("/var/www/html/infrasight/reports") else "/var/www/html/health-reports")
    USERS_FILE = os.environ.get("USERS_FILE", "/opt/infrasight/users.json" if os.path.exists("/opt/infrasight/users.json") else "/opt/health-dashboard/users.json")
    LOG_DIR = os.environ.get("LOG_DIR", "/var/log/infrasight" if os.path.exists("/var/log/infrasight") else "/var/log/health-dashboard")

    # Session
    SESSION_TIMEOUT = int(os.environ.get("SESSION_TIMEOUT", "1800"))  # 30 minutes
    PERMANENT_SESSION_LIFETIME = 86400 * 30  # 30 days for "Remember Me"

    # Authentication
    AUTH_ENABLED = os.environ.get("AUTH_ENABLED", "false").lower() in ("true", "1", "yes")

    # Client Branding
    CLIENT_NAME = os.environ.get("CLIENT_NAME", _conf_data.get("CLIENT_NAME", ""))

    # Report Retention (Default: 10 local client reports, 500 master reports, 180 days / 6 months max age)
    KEEP_LOCAL_REPORTS = int(os.environ.get("KEEP_LOCAL_REPORTS", _conf_data.get("KEEP_LOCAL_REPORTS", "10")))
    KEEP_REMOTE_REPORTS = int(os.environ.get("KEEP_REMOTE_REPORTS", _conf_data.get("KEEP_REMOTE_REPORTS", "500")))
    MAX_REPORT_AGE_DAYS = int(os.environ.get("MAX_REPORT_AGE_DAYS", _conf_data.get("MAX_REPORT_AGE_DAYS", "180")))

    # Server License Limit & Cryptographic Verification
    @classmethod
    def get_license_info(cls):
        from app.license_manager import verify_license_file
        return verify_license_file()

    @classmethod
    def get_max_server_limit(cls):
        from app.license_manager import verify_license_file
        lic_info = verify_license_file()
        return lic_info[1] if len(lic_info) > 1 else 10

    # Property alias
    MAX_SERVER_LIMIT = 100

    # Server
    LISTEN_HOST = os.environ.get("LISTEN_HOST", "0.0.0.0")
    LISTEN_PORT = int(os.environ.get("LISTEN_PORT", "5000"))

