# Enterprise Linux Health Dashboard & Centralized Monitoring Platform

An enterprise-grade, high-performance **Centralized Linux Infrastructure Health & System Monitoring System**. Provides real-time visibility into multi-node Linux infrastructure, automated health checks, security patch management, kernel advisory recommendations, and multi-tenant MSP white-labeling.

---

## 🌟 Key Features

1. **Centralized Enterprise Web Dashboard**: Unified monitoring dashboard for hundreds of RHEL, Rocky, Alma, Oracle, Ubuntu, Amazon Linux, and SUSE servers.
2. **Enterprise Patch & Vulnerability Management**: Package update parser (Available, Security, Critical, Kernel Updates), Patch Compliance Score (%), and reboot requirements.
3. **Multi-OS Kernel Vulnerability Advisor Engine**: Dynamic baseline kernel comparison and CVE security advisory matrix for RHEL (6–10), Ubuntu (18–26 LTS), Rocky, Alma, Oracle (6–10), Amazon Linux, and SUSE.
4. **Before vs. After Infrastructure Drift Comparison Engine**: Side-by-side diff matrix comparing hardware specs, kernel versions, system load, memory, disk, network, running services, and security posture across two scans.
5. **Multi-Tenant MSP Architecture & White-Labeling**: Multi-client isolation, tenant switcher, custom client logos, custom login branding, and custom color themes.
6. **Automated Centralization & Report Retention**: Automated collection of health reports (HTML, TXT, JSON) with automatic retention cleanup rules.
7. **OS-Independent & Lightweight**: Universal support across all major Enterprise Linux distributions with 0% idle memory footprint on client nodes.

---

## 🐧 Supported Operating Systems (100% OS Independent)

Supports all major Enterprise and Community Linux distributions (both legacy and modern versions):

- **Red Hat Enterprise Linux (RHEL)**: 6.x, 7.x, 8.x, 9.x, 10.x
- **Rocky Linux**: 8.x, 9.x
- **AlmaLinux**: 8.x, 9.x
- **Oracle Linux**: 6.x, 7.x, 8.x, 9.x, 10.x
- **Amazon Linux**: Amazon Linux 2, Amazon Linux 2023
- **Ubuntu**: 16.04, 18.04, 20.04, 22.04, 24.04 LTS, 24.10, 25.x, 26.04 LTS
- **Debian**: 9, 10, 11, 12, 13
- **SUSE Linux Enterprise Server (SLES) / openSUSE**: 12, 15

---

## 🔐 Licensing Model & Commercial Capacity Management

### 1. Community Edition vs Commercial Enterprise License
- **Community Edition (Default)**: Free up to **10 Monitored Servers Max**.
- **Commercial Enterprise License**: Custom capacity licenses (e.g., 50, 100, 250, 500, 1000+ monitored servers).

### 2. Architecture & File Distribution Overview

| Server Role / Environment | Artifact | Purpose |
| :--- | :--- | :--- |
| **Vendor Build Environment** | Private Key Generator Utility | Cryptographically signs custom capacity licenses for clients. |
| **Master Application Server** | `/opt/health-reports/license.key`<br>`/etc/health-dashboard.license.backup` | Commercial license key holding capacity limit and expiration date. Validated locally by Master Server. |
| **Monitored Client Nodes** | Standalone `health-check` agent<br>`/etc/health-check.conf` | Collects local system health metrics and uploads data to Master Server. **No license file needed on client nodes.** |

### 3. Cryptographic Anti-Tamper Security & Self-Healing
- **Cryptographic Signature Protection**: License keys are protected by cryptographic digital signatures. Any manual modification to server capacity or expiration date triggers an instant safety fallback to Community Edition limits.
- **Self-Healing Backup**: Automatically restores accidentally deleted license keys from secure system configuration backups (`/etc/health-dashboard.license.backup`).

### 4. Time-Based Offline License Expiration & Grace Period
- **100% Offline Validation**: License validation is performed purely locally on the Master Server without requiring internet access or phone-home calls.
- **14-Day Renewal Grace Period**: Upon expiration, existing active servers continue operating normally for a 14-day renewal grace period while displaying a renewal reminder.
- **Data Preservation Guarantee**: When a license expires, **all historical reports and scan records remain 100% accessible, viewable, and searchable forever**.
- **Reboot-Safe Anti-Tamper Protection**: Built-in clock drift tolerance prevents false lockdowns during server reboots prior to NTP synchronization.

---

## 🏢 Multi-Tenant MSP Architecture & White-Labeling

Designed for MSPs and enterprise organizations managing multiple client environments:

- **Isolated Client Dashboards**: Each client/tenant has an isolated view.
- **Role-Based Access Control (RBAC)**: Assign users to specific client permission scopes so they only see their organization's infrastructure.
- **MSP Tenant Switcher**: Super Admins can toggle between tenant views seamlessly (`🏢 Tenant Scope: Global / Client A / Client B`).
- **Enterprise White-Labeling**: Custom logo, custom organization title, custom login screen, and accent color themes.
- **Tenant Isolation Rules**: Drift comparison is restricted between hosts belonging to different tenants to preserve client data privacy.

---

## 💻 Client Agent Setup & Execution

### Initial Run & Configuration:
```bash
sudo ./health-check
```
1. Prompts for Master Server URL / IP address on first run.
2. Saves settings to `/etc/health-check.conf`.
3. Performs system scan, generates local reports, and uploads data to Master Server.

### Automated Execution (Cron):
The agent script takes ~3 seconds to run and exits immediately with **zero background RAM consumption**. Schedule automated scans via cron:
```bash
0 2 * * * /usr/local/bin/health-check >/dev/null 2>&1
```

---

## ❓ Frequently Asked Questions (FAQ)

### Q1: Is it safe to re-run `install.sh` on the Master Server?
**YES, 100%!** Re-running `install.sh` acts as an in-place repair and upgrade utility. All historical report data, user accounts, and license configurations are preserved without data loss.

### Q2: What happens if the Master Server crashes or goes offline?
Client agents operate independently and will never disrupt client server operations. Scans continue to generate local reports in `/var/log/health-check/`.

To restore a crashed Master Server in 2 minutes:
1. Re-run `install.sh` on a new Master Server instance.
2. Restore your backed-up configuration files and report directory:
   - **Host Reports**: `/var/www/html/health-reports/`
   - **User Accounts Database**: `/opt/health-dashboard/users.json`
   - **Multi-Tenant MSP Configurations**: `/opt/health-dashboard/tenants.json`
   - **Commercial License Backup**: `/etc/health-dashboard.license.backup` (or `/opt/health-reports/license.key`)
3. The Master Dashboard and all historical scan records are restored 100% instantly!

### Q3: When a license expires beyond the grace period, which 10 servers continue uploading?
The earliest 10 registered servers (ranked by registration history) continue uploading normally. Servers beyond 10 are paused for new uploads while all historical scan data remains 100% accessible.

### Q4: What if a client accidentally deletes their `license.key` file?
The Master Server automatically maintains a self-healing backup at `/etc/health-dashboard.license.backup` and restores it automatically upon the next request.

---

## 📞 Support & Commercial Contact

For commercial licensing, capacity upgrades, or custom enterprise feature requests:
- **Author**: Prathap S
- **Email**: [prathaps8675@gmail.com](mailto:prathaps8675@gmail.com)
- **Repository**: [GitHub - Prathaps8675/linux-checklist](https://github.com/Prathaps8675/linux-checklist)
